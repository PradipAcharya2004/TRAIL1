let socket = null;
let connected = false;
let reconnectTimer = null;

function log(...args) {
  console.log("[SWA Helper]", ...args);
}

function connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    return;
  }

  try {
    socket = new WebSocket("ws://127.0.0.1:8765");

    socket.onopen = async () => {
      connected = true;
      log("Connected to desktop app.");
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      socket.send(JSON.stringify({
        type: "hello",
        pageTitle: tab?.title || "",
        url: tab?.url || ""
      }));
    };

    socket.onmessage = async (event) => {
      let command;
      try {
        command = JSON.parse(event.data);
      } catch (e) {
        return;
      }

      const requestId = command.requestId;
      try {
        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        if (!tab || !tab.id) {
          throw new Error("No active tab available.");
        }

        const response = await chrome.tabs.sendMessage(tab.id, command);
        socket.send(JSON.stringify({
          requestId,
          ok: true,
          response,
          snapshot: response?.snapshot
        }));
      } catch (e) {
        socket.send(JSON.stringify({
          requestId,
          ok: false,
          error: e.message || String(e)
        }));
      }
    };

    socket.onclose = () => {
      connected = false;
      log("Disconnected. Retrying...");
      scheduleReconnect();
    };

    socket.onerror = () => {
      connected = false;
      try { socket.close(); } catch (e) {}
      scheduleReconnect();
    };
  } catch (e) {
    connected = false;
    scheduleReconnect();
  }
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, 1500);
}

chrome.runtime.onInstalled.addListener(connect);
chrome.runtime.onStartup.addListener(connect);
chrome.tabs.onActivated.addListener(connect);
chrome.tabs.onUpdated.addListener(connect);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "status") {
    sendResponse({connected});
    return true;
  }
});

connect();
