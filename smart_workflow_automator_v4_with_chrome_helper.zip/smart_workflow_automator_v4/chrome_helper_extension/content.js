function norm(s) {
  return (s || "").toString().replace(/\s+/g, " ").trim().toLowerCase();
}

function visible(el) {
  if (!el) return false;
  const style = window.getComputedStyle(el);
  const rect = el.getBoundingClientRect();
  return style && style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
}

function clickableCandidates() {
  const selectors = [
    "button",
    "a",
    "input[type='button']",
    "input[type='submit']",
    "input[type='reset']",
    "[role='button']",
    "[role='link']",
    "[onclick]",
    "[tabindex]"
  ];
  return Array.from(document.querySelectorAll(selectors.join(","))).filter(visible);
}

function elementText(el) {
  if (!el) return "";
  return (
    el.innerText ||
    el.textContent ||
    el.value ||
    el.getAttribute("aria-label") ||
    el.getAttribute("title") ||
    el.getAttribute("alt") ||
    ""
  ).trim();
}

function findByText(text, match = "contains") {
  const needle = norm(text);
  const candidates = clickableCandidates();
  let best = null;

  for (const el of candidates) {
    const t = norm(elementText(el));
    if (!t) continue;
    const isMatch = match === "exact" ? t === needle : t.includes(needle);
    if (isMatch) {
      best = el;
      break;
    }
  }

  if (best) return best;

  // Fallback: any visible element with text, then click closest clickable parent.
  const all = Array.from(document.querySelectorAll("body *")).filter(visible);
  for (const el of all) {
    const t = norm(elementText(el));
    if (!t) continue;
    const isMatch = match === "exact" ? t === needle : t.includes(needle);
    if (isMatch) {
      return el.closest("button,a,[role='button'],[onclick],[tabindex]") || el;
    }
  }

  return null;
}

function findInput({selector, label, placeholder, name}) {
  if (selector) {
    try {
      const el = document.querySelector(selector);
      if (el && visible(el)) return el;
    } catch (e) {}
  }

  const inputs = Array.from(document.querySelectorAll("input:not([type='hidden']), textarea, [contenteditable='true']")).filter(visible);

  const needles = [label, placeholder, name].filter(Boolean).map(norm);

  for (const el of inputs) {
    const attrs = [
      el.getAttribute("aria-label"),
      el.getAttribute("placeholder"),
      el.getAttribute("name"),
      el.getAttribute("id"),
      el.getAttribute("title"),
    ].map(norm);

    if (attrs.some(a => needles.some(n => a && (a.includes(n) || n.includes(a))))) {
      return el;
    }
  }

  // Try label text connected to input.
  if (label) {
    const labelNeedle = norm(label);
    const labels = Array.from(document.querySelectorAll("label")).filter(visible);
    for (const lab of labels) {
      if (norm(lab.innerText).includes(labelNeedle)) {
        if (lab.htmlFor) {
          const linked = document.getElementById(lab.htmlFor);
          if (linked && visible(linked)) return linked;
        }
        const nested = lab.querySelector("input, textarea, [contenteditable='true']");
        if (nested && visible(nested)) return nested;
      }
    }
  }

  // Common browser/search fallback.
  const search = inputs.find(el => {
    const type = norm(el.getAttribute("type"));
    const ph = norm(el.getAttribute("placeholder"));
    const aria = norm(el.getAttribute("aria-label"));
    return type === "search" || ph.includes("search") || aria.includes("search");
  });
  if (search) return search;

  return inputs[0] || null;
}

function fillElement(el, text) {
  el.scrollIntoView({block: "center", inline: "center"});
  el.focus();

  if (el.isContentEditable) {
    el.innerText = text;
    el.dispatchEvent(new InputEvent("input", {bubbles: true, inputType: "insertText", data: text}));
  } else {
    el.value = "";
    el.dispatchEvent(new Event("input", {bubbles: true}));
    el.value = text;
    el.dispatchEvent(new Event("input", {bubbles: true}));
    el.dispatchEvent(new Event("change", {bubbles: true}));
  }
}

function clickElement(el) {
  el.scrollIntoView({block: "center", inline: "center"});
  const rect = el.getBoundingClientRect();
  const opts = {
    bubbles: true,
    cancelable: true,
    clientX: rect.left + rect.width / 2,
    clientY: rect.top + rect.height / 2,
    view: window
  };
  el.dispatchEvent(new MouseEvent("mouseover", opts));
  el.dispatchEvent(new MouseEvent("mousedown", opts));
  el.dispatchEvent(new MouseEvent("mouseup", opts));
  el.click();
}

function pageSnapshot() {
  const buttons = clickableCandidates().slice(0, 80).map(el => ({
    tag: el.tagName.toLowerCase(),
    text: elementText(el).slice(0, 120),
    role: el.getAttribute("role") || "",
    aria: el.getAttribute("aria-label") || "",
    id: el.id || "",
    class: (el.className || "").toString().slice(0, 80)
  })).filter(x => x.text || x.aria || x.id);

  const inputs = Array.from(document.querySelectorAll("input:not([type='hidden']), textarea, [contenteditable='true']")).filter(visible).slice(0, 50).map(el => ({
    tag: el.tagName.toLowerCase(),
    type: el.getAttribute("type") || "",
    name: el.getAttribute("name") || "",
    id: el.id || "",
    placeholder: el.getAttribute("placeholder") || "",
    aria: el.getAttribute("aria-label") || ""
  }));

  return {
    title: document.title,
    url: location.href,
    buttons,
    inputs,
    bodyTextSample: document.body?.innerText?.slice(0, 1200) || ""
  };
}

async function waitForText(text, timeoutMs) {
  const needle = norm(text);
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (norm(document.body?.innerText || "").includes(needle)) {
      return true;
    }
    await new Promise(r => setTimeout(r, 250));
  }
  return false;
}

chrome.runtime.onMessage.addListener((cmd, sender, sendResponse) => {
  (async () => {
    try {
      const command = cmd.command;

      if (command === "snapshot") {
        sendResponse({ok: true, snapshot: pageSnapshot()});
        return;
      }

      if (command === "browserSearch") {
        const input = findInput({selector: "textarea[name='q'], input[name='q'], input[type='search']"});
        if (input) {
          fillElement(input, cmd.text || "");
          input.dispatchEvent(new KeyboardEvent("keydown", {key: "Enter", code: "Enter", bubbles: true}));
          input.dispatchEvent(new KeyboardEvent("keyup", {key: "Enter", code: "Enter", bubbles: true}));
          if (input.form) input.form.submit();
        } else {
          location.href = "https://www.google.com/search?q=" + encodeURIComponent(cmd.text || "");
        }
        sendResponse({ok: true});
        return;
      }

      if (command === "clickText") {
        const el = findByText(cmd.text || "", cmd.match || "contains");
        if (!el) throw new Error("Could not find clickable text: " + cmd.text);
        clickElement(el);
        sendResponse({ok: true, clickedText: elementText(el)});
        return;
      }

      if (command === "fill") {
        const el = findInput(cmd);
        if (!el) throw new Error("Could not find field.");
        fillElement(el, cmd.text || "");
        if (cmd.pressEnter) {
          el.dispatchEvent(new KeyboardEvent("keydown", {key: "Enter", code: "Enter", bubbles: true}));
          el.dispatchEvent(new KeyboardEvent("keyup", {key: "Enter", code: "Enter", bubbles: true}));
          if (el.form) el.form.submit();
        }
        sendResponse({ok: true});
        return;
      }

      if (command === "waitText") {
        const ok = await waitForText(cmd.text || "", cmd.timeoutMs || 10000);
        if (!ok) throw new Error("Timed out waiting for text: " + cmd.text);
        sendResponse({ok: true});
        return;
      }

      throw new Error("Unknown command: " + command);
    } catch (e) {
      sendResponse({ok: false, error: e.message || String(e)});
    }
  })();
  return true;
});
