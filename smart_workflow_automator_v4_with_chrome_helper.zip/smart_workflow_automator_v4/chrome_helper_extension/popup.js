chrome.runtime.sendMessage({type: "status"}, (resp) => {
  const el = document.getElementById("status");
  if (resp && resp.connected) {
    el.textContent = "Connected to Smart Workflow Automator";
    el.style.color = "green";
  } else {
    el.textContent = "Waiting for desktop app";
    el.style.color = "orange";
  }
});
